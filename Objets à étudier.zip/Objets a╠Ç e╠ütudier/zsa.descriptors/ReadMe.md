# Zsa.descriptors
by Mikhail Malt ([Ircam](http://www.ircam.fr)) & Emmanuel Jourdan ([e--j dev](http://www.e--j.com))

This version requires Max 8 or higher (64 bits only). It will not work with earlier versions (visit [e--j dev](http://www.e--j.com) if you need older version).


##### Easy installation:
Select **Show Package Manager** in the **File** menu, and browse to install **zsa.descriptors**.

##### Manual installation:
Copy the zsa.descriptors folder to your **~/Documents/Max 8/Packages** folder.


[Visit e--j dev for any question!](http://www.e--j.com)